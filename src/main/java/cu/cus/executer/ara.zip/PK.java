package cu.cus.executer;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.CreditCardNumber;
import org.hibernate.validator.constraints.Range;

import java.io.Serializable;

/**
 * DTO for {@link Employee}
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PK implements Serializable {
    private Long id;
    @NotNull
    @Size
    @Pattern
    @Email
    @NotEmpty
    @NotBlank
    private String name;
    private int age;
    @NotNull
    @Size
    @Pattern
    @Digits
    @Email
    @NotEmpty
    @NotBlank
    @CreditCardNumber(ignoreNonDigitCharacters = true)
    private String address;
    @Min
    @Max
    @Digits
    @Positive
    @PositiveOrZero
    @Negative
    @NegativeOrZero
    @Range
    private double salary;
}