package cu.cus.executer;

public class ExampleServiceImpl implements ExampleService {
    @Override
    public String getMessage() {
        return "Hello from ExampleService";
    }
}
