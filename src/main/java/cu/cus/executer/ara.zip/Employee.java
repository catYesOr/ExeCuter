package cu.cus.executer;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Employee {
    private Long id;
    private String name;
	private int age;
	private String address;

	private double salary;

    public Employee(Long id, String name, int age, String address, double salary) {
        super();
        this.id = id;
        this.name = name;
        this.age = age;
        this.address = address;
        this.salary = salary;
    }

}
