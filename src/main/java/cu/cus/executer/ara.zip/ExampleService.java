package cu.cus.executer;

public interface ExampleService {
    String getMessage();
}
