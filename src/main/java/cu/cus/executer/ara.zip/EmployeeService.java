package cu.cus.executer;

import org.springframework.stereotype.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final EmployeeRepository employeeRepository;

    @Autowired
    public UserService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public Employee getEmployeeById(Long id) {
        // Логика для получения сотрудника по id
        return employeeRepository.findById(id);
    }

    // Другие методы сервиса...
}
